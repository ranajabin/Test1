sap.ui.define([
	"sapbtp./project4/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
